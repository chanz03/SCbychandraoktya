using System;
using System.Globalization;

namespace SCbychandraoktya
{
    // Pengaturan kecil yang diingat antar sesi (registry HKCU).
    public static class Prefs
    {
        const string Key = @"Software\SC_by_chandraoktya";
        public static float GetFloat(string name, float def)
        {
            try
            {
                using (var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Key))
                {
                    string v = k == null ? null : k.GetValue(name) as string;
                    float f;
                    if (v != null && float.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out f)) return f;
                }
            }
            catch { }
            return def;
        }
        public static void SetFloat(string name, float value)
        {
            try
            {
                using (var k = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(Key))
                    k.SetValue(name, value.ToString(CultureInfo.InvariantCulture), Microsoft.Win32.RegistryValueKind.String);
            }
            catch { }
        }
        public static float H1Before { get { return GetFloat("H1Before", 12f); } }
        public static float H1After { get { return GetFloat("H1After", 24f); } }
    }

    // Semua akses ke Word memakai late binding (dynamic) sehingga tidak perlu
    // Office PIA / Visual Studio. Konstanta enum Word ditulis sebagai angka.
    public static class Engine
    {
        const int T = -1, F = 0;
        const int AUTO_COLOR = -16777216;   // wdColorAutomatic
        public const string NonBabStyle = "SC Non-BAB";

        static float Cm(float x) { return x * 28.3464567f; }
        static dynamic St(dynamic doc, int id) { return doc.Styles.Item(id); }   // wdBuiltinStyle

        // ---------------- style helpers ----------------
        // Styles.Add menyalin format paragraf tempat kursor berada (termasuk penomoran "BAB 1"),
        // jadi tautan ke list template harus dilepas secara eksplisit.
        static void UnlinkList(dynamic st)
        {
            try
            {
                if (st.ListTemplate != null)
                    st.LinkToListTemplate(new System.Runtime.InteropServices.DispatchWrapper(null));
            }
            catch { }
        }

        static dynamic GetOrCreateStyle(dynamic doc, string name)
        {
            dynamic st;
            try { st = doc.Styles.Item(name); }
            catch { st = doc.Styles.Add(name, 1); }
            st.BaseStyle = (string)St(doc, -1).NameLocal;
            UnlinkList(st);
            st.ParagraphFormat.LeftIndent = 0f;
            st.ParagraphFormat.FirstLineIndent = 0f;
            return st;
        }

        // ---------------- presets ----------------
        public static void ApplyUPNPreset(dynamic doc)
        {
            ApplyBaseStyles(doc, "Times New Roman", new float[] { 14, 12, 12, 12, 12, 12, 12, 12, 12 }, 14);
            ApplyNumbering(doc);
            ApplyPageSetup(doc, 4, 3, 3, 3);   // kiri, atas, kanan, bawah
        }

        public static void ApplyCustomPreset(dynamic doc, string font, float[] h, float nonBab,
            float top, float bottom, float left, float right)
        {
            ApplyBaseStyles(doc, font, h, nonBab);
            ApplyNumbering(doc);
            ApplyPageSetup(doc, left, top, right, bottom);
        }

        public static void EnsureCaptionLabels(dynamic app)
        {
            string[] labels = { "Gambar", "Tabel", "Lampiran", "Persamaan", "Figure", "Table" };
            foreach (var l in labels)
                try { app.CaptionLabels.Add(l); } catch { }   // Word melempar error bila sudah ada
        }

        // ---------------- styles ----------------
        public static void ApplyBaseStyles(dynamic doc, string font, float[] h, float nonBab)
        {
            dynamic n = St(doc, -1);  // Normal
            n.Font.Name = font; n.Font.Size = 12;
            dynamic pf = n.ParagraphFormat;
            pf.Alignment = 3;                 // justify
            pf.LineSpacingRule = 5;           // multiple
            pf.LineSpacing = 18f;             // 1,5 baris
            pf.SpaceAfter = 8f;               // sama dengan template UPN
            pf.FirstLineIndent = 0f;

            for (int lv = 1; lv <= 9; lv++)
            {
                dynamic s = St(doc, -1 - lv);   // Heading 1..9 = -2..-10
                s.Font.Name = font;
                s.Font.Size = h[lv - 1];
                s.Font.Bold = T; s.Font.Italic = F; s.Font.AllCaps = F;
                s.Font.Color = AUTO_COLOR;
                dynamic p = s.ParagraphFormat;
                p.Alignment = lv == 1 ? 1 : 0;
                p.KeepWithNext = T;
                p.FirstLineIndent = 0f;
                if (lv == 1) { p.SpaceBefore = Prefs.H1Before; p.SpaceAfter = Prefs.H1After; p.LineSpacingRule = 0; }
                else
                {
                    p.SpaceBefore = lv == 2 ? 12f : 0f; p.SpaceAfter = 0f;
                    p.LineSpacingRule = 5; p.LineSpacing = 18f;
                }
            }

            dynamic nb = GetOrCreateStyle(doc, NonBabStyle);
            nb.Font.Name = font; nb.Font.Size = nonBab; nb.Font.Bold = T; nb.Font.Color = AUTO_COLOR;
            nb.ParagraphFormat.Alignment = 1;
            nb.ParagraphFormat.SpaceBefore = Prefs.H1Before; nb.ParagraphFormat.SpaceAfter = Prefs.H1After;
            nb.ParagraphFormat.LineSpacingRule = 0;
            nb.ParagraphFormat.KeepWithNext = T;
            nb.ParagraphFormat.OutlineLevel = 1;

            dynamic cap = St(doc, -35);  // Caption
            cap.Font.Name = font; cap.Font.Size = 11; cap.Font.Bold = F; cap.Font.Italic = F; cap.Font.Color = AUTO_COLOR;
            cap.ParagraphFormat.Alignment = 1;
            cap.ParagraphFormat.LineSpacingRule = 0;
            cap.ParagraphFormat.SpaceBefore = 6f; cap.ParagraphFormat.SpaceAfter = 12f;

            try   // judul daftar (DAFTAR ISI dst.) ikut pengaturan font & jarak BAB
            {
                dynamic lt = doc.Styles.Item(ListTitleStyle);
                lt.Font.Name = font; lt.Font.Size = nonBab;
                lt.ParagraphFormat.SpaceBefore = Prefs.H1Before; lt.ParagraphFormat.SpaceAfter = Prefs.H1After;
            }
            catch { }
        }

        // Margin diterapkan ke SETIAP section (dokumen dengan section break tidak lagi tertinggal).
        public static void ApplyPageSetup(dynamic doc, float left, float top, float right, float bottom)
        {
            int n = (int)doc.Sections.Count;
            for (int i = 1; i <= n; i++)
            {
                dynamic p = doc.Sections.Item(i).PageSetup;
                p.PaperSize = 7;   // A4
                p.TopMargin = Cm(top); p.BottomMargin = Cm(bottom);
                p.LeftMargin = Cm(left); p.RightMargin = Cm(right);
            }
        }

        // ---------------- headings & numbering ----------------
        public static void ApplyHeading(dynamic doc, int level)
        {
            try { EnsureNumbering(doc); } catch (Exception ex) { Log.Write("EnsureNumbering: " + ex.Message); }
            doc.Application.Selection.Style = St(doc, -1 - level);
        }

        public static void ApplyNonBab(dynamic doc)
        {
            dynamic nb;
            try { nb = doc.Styles.Item(NonBabStyle); }
            catch
            {
                ApplyBaseStyles(doc, "Times New Roman", new float[] { 14, 12, 12, 12, 12, 12, 12, 12, 12 }, 14);
                nb = doc.Styles.Item(NonBabStyle);
            }
            UnlinkList(nb);   // perbaiki style lama yang terlanjur bernomor BAB
            dynamic sel = doc.Application.Selection;
            sel.Style = nb;
            try { sel.Range.ListFormat.RemoveNumbers(); } catch { }
        }

        static void EnsureNumbering(dynamic doc)
        {
            if (St(doc, -2).ListTemplate == null || St(doc, -3).ListTemplate == null)
                ApplyNumbering(doc);
        }

        public static void ApplyNumbering(dynamic doc)
        {
            dynamic lt = doc.ListTemplates.Add(true);
            dynamic lv1 = lt.ListLevels.Item(1);
            lv1.NumberFormat = "BAB %1";
            lv1.NumberStyle = 1;              // huruf Romawi kapital
            lv1.TrailingCharacter = 1;        // spasi
            lv1.NumberPosition = 0f; lv1.TextPosition = 0f; lv1.StartAt = 1;
            lv1.LinkedStyle = (string)St(doc, -2).NameLocal;

            string[] fmt = { null, null, "%1.%2", "%1.%2.%3", "%1.%2.%3.%4" };
            for (int i = 2; i <= 4; i++)
            {
                dynamic l = lt.ListLevels.Item(i);
                l.NumberFormat = fmt[i];
                l.NumberStyle = 253;          // Legal -> semua tingkat tampil angka Arab
                l.TrailingCharacter = 0;      // tab
                l.NumberPosition = 0f;
                l.TextPosition = Cm(1.27f);
                l.TabPosition = Cm(1.27f);
                l.ResetOnHigher = i - 1;
                l.StartAt = 1;
                l.LinkedStyle = (string)St(doc, -1 - i).NameLocal;
            }
        }

        // Versi 1.0.4 sempat mengikat Ctrl+1..4 ke style Heading di Normal.dotm. Fungsi ini membersihkannya.
        public static void ClearHeadingShortcuts(dynamic app)
        {
            dynamic old = app.CustomizationContext;
            try
            {
                app.CustomizationContext = app.NormalTemplate;
                for (int lv = 1; lv <= 4; lv++)
                {
                    int code = (int)app.BuildKeyCode(512 /*Ctrl*/, 48 + lv);
                    try { dynamic kb = app.FindKey(code); if (kb != null && (int)kb.KeyCategory == 5) kb.Clear(); } catch { }
                }
            }
            finally { try { app.CustomizationContext = old; } catch { } }
        }

        // ---------------- chapter counter ----------------
        // Menghitung jumlah paragraf Heading 1 sebelum kursor (memakai Find, jauh lebih cepat daripada loop paragraf).
        static int CurrentChapter(dynamic doc)
        {
            int pos = (int)doc.Application.Selection.Range.Start;
            int n = 0, start = 0;
            dynamic h1 = St(doc, -2);
            while (start < pos)
            {
                dynamic r = doc.Range(start, pos);
                dynamic f = r.Find;
                f.ClearFormatting();
                f.Text = ""; f.Style = h1; f.Forward = true; f.Wrap = 0; f.Format = true;
                if (!(bool)f.Execute()) break;
                n++;
                int end = (int)r.End;
                if (end <= start) break;
                start = end;
            }
            return Math.Max(n, 1);
        }

        // ---------------- fields / captions ----------------
        static void InsertField(dynamic sel, string code, bool bold)
        {
            dynamic r = sel.Range;
            r.Collapse(1);  // start
            dynamic fld = r.Fields.Add(r, -1, code, false);
            fld.Update();
            if (bold) fld.Result.Font.Bold = T;
            int end = (int)fld.Result.End + 1;   // lewati penanda akhir field
            sel.SetRange(end, end);
        }

        public static void InsertCaption(dynamic doc, string label, bool byChapter)
        {
            EnsureCaptionLabels(doc.Application);
            dynamic sel = doc.Application.Selection;
            sel.Style = St(doc, -35);
            sel.Font.Bold = T; sel.Font.Italic = F;
            sel.TypeText(label + " ");
            if (byChapter)
            {
                sel.TypeText(CurrentChapter(doc) + ".");
                InsertField(sel, "SEQ " + label + " \\* ARABIC \\s 1", true);
            }
            else
            {
                InsertField(sel, "SEQ " + label + " \\* ALPHABETIC", true);
            }
            sel.Font.Bold = T;
            sel.TypeText(".");
            sel.Font.Bold = F; sel.Font.Italic = F;
            sel.TypeText(" ");
        }

        // ---------------- equation ----------------
        // Rumus: [tab tengah] rumus [tab kanan] (BAB-urut), dalam satu baris, tanpa spasi sesudahnya.
        // Contoh:                 L(r,s,t) = ...                       (2-2)
        public static void InsertEquation(dynamic doc)
        {
            dynamic app = doc.Application;
            dynamic sel = app.Selection;
            int ch = CurrentChapter(doc);

            // mulai dari paragraf kosong
            dynamic para = sel.Paragraphs.Item(1).Range;
            if (((string)para.Text).Trim(Blank).Length > 0)
            {
                int e = (int)para.End - 1;
                sel.SetRange(e, e);
                sel.TypeParagraph();
                sel.ParagraphFormat.Reset();
            }
            int start = (int)sel.Start;

            dynamic ps = doc.PageSetup;
            float width = (float)ps.PageWidth - (float)ps.LeftMargin - (float)ps.RightMargin;
            dynamic pf = sel.ParagraphFormat;
            pf.Alignment = 0; pf.FirstLineIndent = 0f;
            pf.SpaceBefore = 0f; pf.SpaceAfter = 0f;      // kalimat lanjutan menempel tanpa spasi
            pf.TabStops.ClearAll();
            pf.TabStops.Add(width / 2f, 1, 0);            // tab tengah  -> rumus
            pf.TabStops.Add(width, 2, 0);                 // tab kanan   -> nomor

            // susun dulu: <tab><tab>(BAB-urut), lalu rumus disisipkan di antara kedua tab
            sel.TypeText("\t\t(" + ch + "-");
            InsertField(sel, "SEQ Persamaan \\* ARABIC \\s 1", false);
            sel.TypeText(")");
            sel.TypeParagraph();
            sel.ParagraphFormat.Reset();                   // paragraf berikutnya normal
            sel.SetRange(start + 1, start + 1);            // di antara dua tab

            try { app.CommandBars.ExecuteMso("EquationInsertNew"); }   // sisipkan equation, kursor masuk ke dalamnya
            catch (Exception ex)
            {
                Log.Write("ExecuteMso equation gagal: " + ex.Message);
                doc.OMaths.Add(sel.Range);
            }
        }

        // ---------------- lists & numbering ----------------
        public static void UpdateLists(dynamic doc)
        {
            doc.Fields.Update();
            foreach (dynamic t in doc.TablesOfContents) t.Update();
            foreach (dynamic f in doc.TablesOfFigures) f.Update();
        }

        // ---------------- daftar isi / gambar / tabel / rumus ----------------
        const string ListTitleStyle = "SC Judul Daftar";

        static void EnsureListTitleStyle(dynamic doc)
        {
            dynamic nb;
            try { nb = doc.Styles.Item(NonBabStyle); }
            catch
            {
                ApplyBaseStyles(doc, "Times New Roman", new float[] { 14, 12, 12, 12, 12, 12, 12, 12, 12 }, 14);
                nb = doc.Styles.Item(NonBabStyle);
            }
            dynamic s = GetOrCreateStyle(doc, ListTitleStyle);
            s.Font.Name = nb.Font.Name; s.Font.Size = nb.Font.Size; s.Font.Bold = T; s.Font.Color = AUTO_COLOR;
            dynamic pf = s.ParagraphFormat;
            pf.Alignment = 1; pf.SpaceBefore = Prefs.H1Before; pf.SpaceAfter = Prefs.H1After;
            pf.LineSpacingRule = 0; pf.KeepWithNext = T;
            pf.OutlineLevel = 10;   // teks biasa: judul daftar tidak ikut masuk Daftar Isi
        }

        static void TidyListStyles(dynamic doc)
        {
            int[] ids = { -20, -21, -22, -23, -36 };   // TOC 1-4, Table of Figures
            foreach (int id in ids)
            {
                try
                {
                    dynamic s = St(doc, id);
                    s.Font.Color = AUTO_COLOR;
                    dynamic pf = s.ParagraphFormat;
                    pf.Alignment = 0; pf.LineSpacingRule = 0; pf.SpaceBefore = 0f; pf.SpaceAfter = 6f;
                }
                catch { }
            }
        }

        static dynamic FindList(dynamic doc, string kind)
        {
            if (kind == "isi")
                return (int)doc.TablesOfContents.Count > 0 ? doc.TablesOfContents.Item(1) : null;
            foreach (dynamic t in doc.TablesOfFigures)
            {
                try
                {
                    string code = (string)t.Range.Fields.Item(1).Code.Text;
                    if (code.IndexOf("\"" + kind + "\"", StringComparison.OrdinalIgnoreCase) >= 0) return t;
                }
                catch { }
            }
            return null;
        }

        // kind: "isi", "Gambar", "Tabel", "Persamaan". Mengembalikan true jika daftar lama diperbarui.
        public static bool InsertList(dynamic doc, string kind)
        {
            EnsureCaptionLabels(doc.Application);
            TidyListStyles(doc);
            dynamic existing = FindList(doc, kind);
            if (existing != null) { existing.Update(); return true; }

            EnsureListTitleStyle(doc);
            string title = kind == "isi" ? "DAFTAR ISI"
                         : kind == "Gambar" ? "DAFTAR GAMBAR"
                         : kind == "Figure" ? "LIST OF FIGURES"
                         : kind == "Tabel" ? "DAFTAR TABEL"
                         : kind == "Table" ? "LIST OF TABLES"
                         : "DAFTAR RUMUS";
            dynamic sel = doc.Application.Selection;
            sel.Style = doc.Styles.Item(ListTitleStyle);
            sel.TypeText(title);
            sel.TypeParagraph();
            sel.Style = St(doc, -1);
            dynamic rng = sel.Range;
            object M = Type.Missing;
            dynamic added;
            if (kind == "isi")
                added = doc.TablesOfContents.Add(rng, true, 1, 4, M, M, true, true, M, true, M, true);
            else
                added = doc.TablesOfFigures.Add(rng, kind, true, M, M, M, M, M, true, true, M, true);
            try { int e = (int)added.Range.End; sel.SetRange(e, e); } catch { }
            return false;
        }

        // ---------------- penomoran halaman ----------------
        // Sebelum BAB pertama (Heading 1): romawi (i, ii, ...). Mulai BAB pertama: angka, mulai dari 1.
        public static void ApplyPageNumbering(dynamic doc)
        {
            dynamic h1 = St(doc, -2);
            int babStart = FindFirstBab(doc, h1);
            if (babStart < 0)
                throw new Exception("Belum ada BAB (Heading 1) di dokumen. Buat BAB pertama dulu dengan Ctrl+1.");

            // pastikan BAB pertama berada di awal section baru
            int end0 = (int)doc.Content.End;
            if (babStart > end0) babStart = end0;
            dynamic sec = doc.Range(babStart, babStart).Sections.Item(1);
            if (babStart > 0 && (int)sec.Range.Start != babStart)
            {
                doc.Range(babStart, babStart).InsertBreak(2);   // section break (halaman berikutnya)
                // paragraf pemuat section break mewarisi style Heading 1 -> kembalikan ke Normal
                CleanBlankPara(doc, doc.Range(babStart, babStart + 1).Paragraphs.Item(1).Range);
                babStart = babStart + 1;                         // BAB bergeser 1 karakter
            }
            int endNow = (int)doc.Content.End;
            if (babStart > endNow) babStart = endNow;
            int k = (int)doc.Range(babStart, babStart).Sections.Item(1).Index;

            string font = (string)St(doc, -1).Font.Name;
            int count = (int)doc.Sections.Count;
            for (int i = 1; i <= count; i++)
            {
                dynamic ft = doc.Sections.Item(i).Footers.Item(1);   // footer utama
                bool setup = (i == 1 || i == k);
                if (i > 1) ft.LinkToPrevious = !setup;
                if (setup)
                {
                    ft.Range.Text = "";
                    dynamic r = ft.Range;
                    r.Collapse(1);
                    r.Fields.Add(r, 33);   // PAGE
                    ft.Range.ParagraphFormat.Alignment = 1;
                    ft.Range.Font.Name = font; ft.Range.Font.Size = 12;
                }
                ft.PageNumbers.NumberStyle = (i < k) ? 2 : 0;   // 2 = romawi kecil, 0 = angka Arab
                bool restart = (i == 1 || i == k);
                ft.PageNumbers.RestartNumberingAtSection = restart;
                if (restart) ft.PageNumbers.StartingNumber = 1;
            }
        }

        static readonly char[] Blank = { '\r', '\n', '\f', '\v', '\a', ' ', '\t' };

        static void CleanBlankPara(dynamic doc, dynamic para)
        {
            para.Style = St(doc, -1);
            try { para.ListFormat.RemoveNumbers(); } catch { }
            para.ParagraphFormat.SpaceBefore = 0f; para.ParagraphFormat.SpaceAfter = 0f;
            para.ParagraphFormat.LineSpacingRule = 0;
        }

        // Mencari BAB pertama (Heading 1). Paragraf Heading 1 yang hanya berisi section break
        // (sisa versi lama) dikembalikan ke Normal. Heading kosong biasa tetap dihitung sebagai BAB.
        static int FindFirstBab(dynamic doc, dynamic h1)
        {
            int from = 0;
            for (int guard = 0; guard < 200; guard++)
            {
                dynamic r = doc.Range(from, doc.Content.End);
                dynamic f = r.Find;
                f.ClearFormatting();
                f.Text = ""; f.Style = h1; f.Forward = true; f.Wrap = 0; f.Format = true;
                if (!(bool)f.Execute()) return -1;
                dynamic para = r.Paragraphs.Item(1).Range;
                string t = (string)para.Text;
                if (t.IndexOf('\f') >= 0 && t.Trim(Blank).Length == 0)
                {
                    CleanBlankPara(doc, para);
                    from = (int)para.End;
                    continue;
                }
                return (int)r.Start;
            }
            return -1;
        }
    }
}
