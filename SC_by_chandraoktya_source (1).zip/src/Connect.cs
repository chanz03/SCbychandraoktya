using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

[assembly: AssemblyTitle("SC by chandraoktya")]
[assembly: AssemblyCompany("chandraoktya.id")]
[assembly: AssemblyProduct("SC by chandraoktya")]
[assembly: AssemblyCopyright("Copyright (c) 2026 chandraoktya.id (Chandra Tri Oktyawardhana)")]
[assembly: AssemblyDescription("Word formatting assistant untuk skripsi dan laporan")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]

namespace SCbychandraoktya
{
    internal static class Log
    {
        public static void Write(string m)
        {
            try
            {
                string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SC_by_chandraoktya");
                Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, "log.txt"), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + m + "\r\n");
            }
            catch { }
        }
    }

    public enum ext_ConnectMode { ext_cm_AfterStartup = 0, ext_cm_Startup = 1, ext_cm_External = 2, ext_cm_CommandLine = 3 }
    public enum ext_DisconnectMode { ext_dm_HostShutdown = 0, ext_dm_UserClosed = 1 }

    [ComVisible(true), Guid("B65AD801-ABAF-11D0-BB8B-00A0C90F2744"), InterfaceType(ComInterfaceType.InterfaceIsDual)]
    public interface IDTExtensibility2
    {
        void OnConnection([MarshalAs(UnmanagedType.IDispatch)] object Application, ext_ConnectMode ConnectMode,
            [MarshalAs(UnmanagedType.IDispatch)] object AddInInst, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref Array custom);
        void OnDisconnection(ext_DisconnectMode RemoveMode, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref Array custom);
        void OnAddInsUpdate([MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref Array custom);
        void OnStartupComplete([MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref Array custom);
        void OnBeginShutdown([MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref Array custom);
    }

    [ComVisible(true), Guid("000C0396-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsDual)]
    public interface IRibbonExtensibility
    {
        [DispId(1)]
        [return: MarshalAs(UnmanagedType.BStr)]
        string GetCustomUI([In, MarshalAs(UnmanagedType.BStr)] string RibbonID);
    }

    [ComVisible(true)]
    [Guid("7C0E3B5A-2D4F-4B8E-9A61-5C3F1E8D2A47")]
    [ProgId("SCbychandraoktya.Connect")]
    [ClassInterface(ClassInterfaceType.AutoDispatch)]
    public class Connect : IDTExtensibility2, IRibbonExtensibility
    {
        dynamic app;
        object ribbonUi;

        // ---------- keyboard hook ----------
        delegate IntPtr HookProc(int code, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll")] static extern IntPtr SetWindowsHookEx(int id, HookProc fn, IntPtr mod, uint tid);
        [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int code, IntPtr w, IntPtr l);
        [DllImport("user32.dll")] static extern short GetKeyState(int vk);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll", CharSet = CharSet.Auto)] static extern int GetClassName(IntPtr h, StringBuilder sb, int max);
        [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();

        HookProc hookProc;
        Control sync;
        IntPtr hook = IntPtr.Zero;

        // ---------- IDTExtensibility2 ----------
        public void OnConnection(object Application, ext_ConnectMode ConnectMode, object AddInInst, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref Array custom)
        {
            try
            {
                Log.Write("OnConnection mode=" + ConnectMode);
                app = Application;
                if (ShortcutsEnabledPref()) InstallHook();
                CleanupOldBindingsOnce();
                Log.Write("OnConnection ok");
            }
            catch (Exception ex) { Log.Write("OnConnection error: " + ex); }
        }

        public void OnDisconnection(ext_DisconnectMode RemoveMode, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref Array custom)
        {
            try { RemoveHook(); } catch { }
            app = null; ribbonUi = null;
            Log.Write("OnDisconnection");
        }

        // Shortcut hook: OFF secara default, dinyalakan dari ribbon (tombol "Aktifkan Shortcut").
        static bool ShortcutsEnabledPref()
        {
            try
            {
                using (var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\SC_by_chandraoktya"))
                    return k != null && Convert.ToInt32(k.GetValue("EnableShortcuts", 0)) == 1;
            }
            catch { return false; }
        }
        static void SetShortcutsPref(bool on)
        {
            try
            {
                using (var k = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\SC_by_chandraoktya"))
                    k.SetValue("EnableShortcuts", on ? 1 : 0, Microsoft.Win32.RegistryValueKind.DWord);
            }
            catch { }
        }
        void CleanupOldBindingsOnce()
        {
            try
            {
                using (var k = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\SC_by_chandraoktya"))
                {
                    if (Convert.ToInt32(k.GetValue("CleanedKeyBindings", 0)) == 1) return;
                    Engine.ClearHeadingShortcuts(app);
                    k.SetValue("CleanedKeyBindings", 1, Microsoft.Win32.RegistryValueKind.DWord);
                }
            }
            catch (Exception ex) { Log.Write("CleanupOldBindings: " + ex.Message); }
        }

        void InstallHook()
        {
            if (hook != IntPtr.Zero) return;
            if (sync == null) { sync = new Control(); IntPtr h = sync.Handle; }   // dibuat di thread UI Word
            hookProc = new HookProc(KeyHook);
            hook = SetWindowsHookEx(2 /*WH_KEYBOARD*/, hookProc, IntPtr.Zero, GetCurrentThreadId());
            Log.Write("hook installed: " + hook);
        }
        void RemoveHook()
        {
            if (hook != IntPtr.Zero) { UnhookWindowsHookEx(hook); hook = IntPtr.Zero; Log.Write("hook removed"); }
        }
        public void ToggleShortcuts(object c, bool pressed)
        {
            try
            {
                if (pressed) { InstallHook(); SetShortcutsPref(true); }
                else { RemoveHook(); SetShortcutsPref(false); }
            }
            catch (Exception ex) { Log.Write("ToggleShortcuts error: " + ex); }
        }
        public bool GetShortcutsPressed(object c) { return hook != IntPtr.Zero; }

        public void OnAddInsUpdate([MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref Array custom) { }
        public void OnStartupComplete([MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref Array custom) { }
        public void OnBeginShutdown([MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref Array custom) { }

        // ---------- IRibbonExtensibility ----------
        public string GetCustomUI(string RibbonID)
        {
            try
            {
                Log.Write("GetCustomUI " + RibbonID);
                using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("Ribbon.xml"))
                using (var r = new StreamReader(s, Encoding.UTF8))
                    return r.ReadToEnd();
            }
            catch (Exception ex) { Log.Write("GetCustomUI error: " + ex); return null; }
        }

        public void Ribbon_Load(object ribbonUI) { ribbonUi = ribbonUI; Log.Write("Ribbon_Load"); }

        // ---------- helpers ----------
        const string Title = "SC by chandraoktya";

        static string BaseDir
        {
            get { return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location); }
        }

        dynamic Doc()
        {
            if ((int)app.Documents.Count == 0)
            {
                MessageBox.Show("Buka atau buat dokumen Word terlebih dahulu.", Title);
                return null;
            }
            return app.ActiveDocument;
        }

        void Run(Action<dynamic> a)
        {
            try
            {
                var d = Doc();
                if (d != null) a(d);
            }
            catch (Exception ex)
            {
                Log.Write("Run error: " + ex); MessageBox.Show("Terjadi kesalahan:\n" + ex.Message, Title);
            }
        }

        // ---------- keyboard shortcuts ----------
        // Hook hanya memutuskan "tombol ini milik kita"; perintah ke Word dijalankan SETELAH hook selesai
        // (lewat BeginInvoke) supaya Word tidak dipanggil ulang di tengah pemrosesan keyboard.
        IntPtr KeyHook(int code, IntPtr wParam, IntPtr lParam)
        {
            try
            {
                if (code == 0)
                {
                    long lp = lParam.ToInt64();
                    bool keyDown = (lp & 0x80000000L) == 0;
                    bool ctrl = (GetKeyState(0x11) & 0x8000) != 0;
                    bool alt = (GetKeyState(0x12) & 0x8000) != 0;
                    bool shift = (GetKeyState(0x10) & 0x8000) != 0;
                    if (keyDown && ctrl && !shift && sync != null && IsWordMainWindow())
                    {
                        int vk = wParam.ToInt32();
                        Action act = ShortcutAction(vk, alt);
                        if (act != null)
                        {
                            Log.Write("shortcut vk=0x" + vk.ToString("X") + " alt=" + alt);
                            sync.BeginInvoke(act);
                            return (IntPtr)1;
                        }
                    }
                }
            }
            catch (Exception ex) { Log.Write("KeyHook error: " + ex.Message); }
            return CallNextHookEx(hook, code, wParam, lParam);
        }

        static bool IsWordMainWindow()
        {
            var sb = new StringBuilder(64);
            GetClassName(GetForegroundWindow(), sb, 64);
            return sb.ToString() == "OpusApp";
        }

        Action ShortcutAction(int vk, bool alt)
        {
            if (app == null || !alt) return null;
            int digit = (vk >= 0x31 && vk <= 0x39) ? vk - 0x30 : (vk >= 0x61 && vk <= 0x69) ? vk - 0x60 : 0;   // baris atas & numpad
            if (digit >= 1 && digit <= 4) { int lv = digit; return () => Run(d => Engine.ApplyHeading(d, lv)); }
            if (digit == 5) return () => Run(d => Engine.ApplyNonBab(d));
            switch (vk)
            {
                case 0x52: return () => Run(d => Engine.InsertEquation(d));
                case 0x47: return () => Run(d => Engine.InsertCaption(d, FigLabel(), true));
                case 0x54: return () => Run(d => Engine.InsertCaption(d, TabLabel(), true));
                case 0x4C: return () => Run(d => Engine.InsertCaption(d, "Lampiran", false));
                case 0x55: return () => Run(d => Engine.UpdateLists(d));
                case 0x42: return () => Run(d => app.Selection.InsertBreak(2));
                case 0x50: return () => Run(d => Engine.ApplyPageNumbering(d));
            }
            return null;
        }

        // ---------- pilihan label caption (Gambar/Figure, Tabel/Table) ----------
        static string GetLabelPref(string name, string a, string b)
        {
            try
            {
                using (var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\SC_by_chandraoktya"))
                {
                    string v = k == null ? null : k.GetValue(name) as string;
                    if (v == b) return b;
                }
            }
            catch { }
            return a;
        }
        static void SetLabelPref(string name, string v)
        {
            try
            {
                using (var k = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\SC_by_chandraoktya"))
                    k.SetValue(name, v, Microsoft.Win32.RegistryValueKind.String);
            }
            catch { }
        }
        static string FigLabel() { return GetLabelPref("FigureLabel", "Gambar", "Figure"); }
        static string TabLabel() { return GetLabelPref("TableLabel", "Tabel", "Table"); }
        void Refresh(string id)
        {
            try { ((dynamic)ribbonUi).InvalidateControl(id); } catch { }
        }

        // ---------- ribbon callbacks (dipanggil Office lewat IDispatch) ----------
        public void SetupDocument(object c) { Run(d => { using (var f = new SetupDialog(d)) f.ShowDialog(); }); }
        public void ApplyUPN(object c) { Run(d => { Engine.ApplyUPNPreset(d); MessageBox.Show("Preset Template Skripsi UPN diterapkan.", Title); }); }
        public void ExportPdf(object c)
        {
            Run(d =>
            {
                using (var dlg = new SaveFileDialog())
                {
                    dlg.Filter = "PDF (*.pdf)|*.pdf";
                    dlg.FileName = Path.GetFileNameWithoutExtension((string)d.Name) + ".pdf";
                    if (dlg.ShowDialog() != DialogResult.OK) return;
                    d.ExportAsFixedFormat(dlg.FileName, 17 /*wdExportFormatPDF*/);
                }
            });
        }
        public void PrintDocument(object c) { Run(d => d.PrintOut()); }
        public void PageNumbering(object c) { Run(d => { Engine.ApplyPageNumbering(d); MessageBox.Show("Penomoran halaman diterapkan:\nsebelum BAB I = romawi (i, ii, ...)\nmulai BAB I = angka 1, 2, 3, ...", Title); }); }
        public void CaptionGambar(object c) { Run(d => Engine.InsertCaption(d, FigLabel(), true)); }
        public void SetFigId(object c) { SetLabelPref("FigureLabel", "Gambar"); Refresh("fig"); CaptionGambar(c); }
        public void SetFigEn(object c) { SetLabelPref("FigureLabel", "Figure"); Refresh("fig"); CaptionGambar(c); }
        public string GetFigLabel(object c) { return "Caption " + FigLabel(); }
        public void CaptionTabel(object c) { Run(d => Engine.InsertCaption(d, TabLabel(), true)); }
        public void SetTabId(object c) { SetLabelPref("TableLabel", "Tabel"); Refresh("tab"); CaptionTabel(c); }
        public void SetTabEn(object c) { SetLabelPref("TableLabel", "Table"); Refresh("tab"); CaptionTabel(c); }
        public string GetTabLabel(object c) { return "Caption " + TabLabel(); }
        public void CaptionLampiran(object c) { Run(d => Engine.InsertCaption(d, "Lampiran", false)); }
        void ListBtn(string kind)
        {
            Run(d =>
            {
                bool updated = Engine.InsertList(d, kind);
                if (updated) MessageBox.Show("Daftar sudah ada, jadi diperbarui.", Title);
            });
        }
        public void DaftarIsi(object c) { ListBtn("isi"); }
        public void DaftarGambar(object c) { ListBtn(FigLabel()); }
        public void DaftarTabel(object c) { ListBtn(TabLabel()); }
        public void UpdateLists(object c) { Run(d => Engine.UpdateLists(d)); }
        public void InsertSection(object c) { Run(d => app.Selection.InsertBreak(2)); }
        public void ToggleMarks(object c, bool pressed) { Run(d => app.ActiveWindow.View.ShowAll = pressed); }
        public void Heading1(object c) { Run(d => Engine.ApplyHeading(d, 1)); }
        public void Heading2(object c) { Run(d => Engine.ApplyHeading(d, 2)); }
        public void Heading3(object c) { Run(d => Engine.ApplyHeading(d, 3)); }
        public void Heading4(object c) { Run(d => Engine.ApplyHeading(d, 4)); }
        public void NonBab(object c) { Run(d => Engine.ApplyNonBab(d)); }
        public void CopyFormat(object c) { Run(d => app.Selection.CopyFormat()); }
        public void PasteFormat(object c) { Run(d => app.Selection.PasteFormat()); }
        public void Equation(object c) { Run(d => Engine.InsertEquation(d)); }
        public void Tutorial(object c) { MessageBox.Show(HelpText.Tutorial, Title); }
        public void Shortcuts(object c) { MessageBox.Show(HelpText.Shortcuts, Title); }
        public void OtherHelp(object c) { MessageBox.Show("SC by chandraoktya\nWord formatting assistant untuk skripsi/laporan.\nVersi 1.0.9\n\nDibuat oleh Chandra Tri Oktyawardhana\nchandraoktya.id  |  instagram.com/chandraoktya", "Lainnya"); }
        public void Instagram(object c)
        {
            try { Process.Start(new ProcessStartInfo("https://www.instagram.com/chandraoktya/") { UseShellExecute = true }); } catch { }
        }
        public void Donation(object c)
        {
            try
            {
                string qr = Path.Combine(BaseDir, "Assets", "donation_qr.png");
                if (!File.Exists(qr)) { MessageBox.Show("File QR donasi tidak ditemukan:\n" + qr, Title); return; }
                using (var img = System.Drawing.Image.FromFile(qr))
                using (var f = new Form())
                {
                    f.Text = "Donasi - SC by chandraoktya";
                    f.StartPosition = FormStartPosition.CenterScreen;
                    f.FormBorderStyle = FormBorderStyle.FixedDialog;
                    f.MaximizeBox = false; f.MinimizeBox = false;
                    f.ClientSize = new System.Drawing.Size(500, 700);
                    var lbl = new Label { Text = "Terima kasih sudah mendukung! Scan dengan aplikasi bank / e-wallet.", Dock = DockStyle.Top, Height = 34, TextAlign = System.Drawing.ContentAlignment.MiddleCenter };
                    var pb = new PictureBox { Image = img, SizeMode = PictureBoxSizeMode.Zoom, Dock = DockStyle.Fill };
                    f.Controls.Add(pb);
                    f.Controls.Add(lbl);
                    f.ShowDialog();
                }
            }
            catch (Exception ex) { Log.Write("Donation error: " + ex.Message); MessageBox.Show("Gagal menampilkan QR donasi:\n" + ex.Message, Title); }
        }
    }

    internal static class HelpText
    {
        public const string Tutorial =
@"SC by chandraoktya - Tutorial

1. Setup Dokumen
Pilih font, ukuran Heading 1-9, ukuran judul non-BAB, dan margin.

2. Format
Template Skripsi UPN menerapkan preset (margin 4-3-3-3, spasi 1,5).
Setup Dokumen membuka pengaturan manual.

3. Struktur (aktifkan tombol Aktifkan Shortcut dulu)
Ctrl+Alt+1 = BAB
Ctrl+Alt+2 = Heading 2
Ctrl+Alt+3 = Heading 3
Ctrl+Alt+4 = Heading 4
Ctrl+Alt+5 = Heading 1 non-BAB

4. Caption
Gambar berada di bawah gambar; Tabel berada di atas tabel.
Tombol Caption punya menu panah: pilih Gambar/Figure atau Tabel/Table.
Pilihan terakhir diingat (juga untuk shortcut dan Daftar Gambar/Tabel).
Nomor caption mengikuti BAB (mis. Gambar 2.1).

5. Rumus
Rumus membuat satu baris: rumus di tengah, nomor (BAB-urut) otomatis di kanan.

6. Daftar & nomor halaman
Letakkan kursor di tempat daftar, lalu klik Daftar Isi / Gambar / Tabel / Rumus.
Page Numbering: romawi sebelum BAB I, angka mulai 1 dari BAB I.";

        public const string Shortcuts =
@"Shortcut SC by chandraoktya

Ctrl+Alt+1   BAB
Ctrl+Alt+2   Heading 2
Ctrl+Alt+3   Heading 3
Ctrl+Alt+4   Heading 4
Ctrl+Alt+5   Heading 1 non-BAB
Ctrl+Alt+R   Rumus
Ctrl+Alt+G   Caption Gambar
Ctrl+Alt+T   Caption Tabel
Ctrl+Alt+L   Caption Lampiran
Ctrl+Alt+U   Update daftar
Ctrl+Alt+B   Section Break
Ctrl+Alt+P   Page Numbering";
    }
}
