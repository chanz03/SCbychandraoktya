using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace SCbychandraoktya
{
    public class SetupDialog : Form
    {
        static readonly string[] FontSizes = { "10", "11", "12", "13", "14", "16", "18", "20" };
        static readonly string[] Margins = { "2", "2.5", "3", "4" };
        static readonly string[] Spacings = { "0", "6", "12", "18", "24", "30", "36", "42" };
        const float CmPt = 28.3464567f;

        readonly dynamic doc;
        ComboBox font, nonbab, top, bottom, left, right, h1before, h1after;
        readonly ComboBox[] h = new ComboBox[9];

        public SetupDialog(object document)
        {
            doc = document;
            Text = "SC by chandraoktya - Setup Dokumen";
            ClientSize = new Size(740, 540);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
            Build();
            LoadFromDocument();
        }

        ComboBox Box(string[] items, int x, int y, int w)
        {
            var b = new ComboBox { Left = x, Top = y, Width = w, DropDownStyle = ComboBoxStyle.DropDown };
            b.Items.AddRange(items);
            Controls.Add(b);
            return b;
        }

        void Lbl(string s, int x, int y, int w)
        {
            Controls.Add(new Label { Text = s, Left = x, Top = y + 4, Width = w });
        }

        void Build()
        {
            Lbl("Jenis Font", 25, 25, 120);
            font = new ComboBox { Left = 150, Top = 20, Width = 220, DropDownStyle = ComboBoxStyle.DropDown };
            font.Items.AddRange(new object[] { "Times New Roman", "Arial", "Calibri", "Cambria", "Book Antiqua" });
            Controls.Add(font);

            int[] xs = { 25, 270, 25, 270, 25, 270, 25, 270, 25, 270 };
            int[] ys = { 75, 75, 125, 125, 175, 175, 225, 225, 275, 275 };
            for (int i = 0; i < 9; i++)
            {
                Lbl("Heading " + (i + 1), xs[i], ys[i], 120);
                h[i] = Box(FontSizes, xs[i] + 125, ys[i], 95);
            }
            Lbl("Non-BAB (Judul)", xs[9], ys[9], 120);
            nonbab = Box(FontSizes, xs[9] + 125, ys[9], 95);

            Lbl("Jarak BAB ke atas (pt)", 25, 335, 125);   h1before = Box(Spacings, 155, 330, 95);
            Lbl("Jarak BAB ke bawah (pt)", 270, 335, 125); h1after = Box(Spacings, 395, 330, 95);

            Lbl("Margin Atas (cm)", 25, 395, 125);    top = Box(Margins, 155, 390, 95);
            Lbl("Margin Bawah (cm)", 270, 395, 125);  bottom = Box(Margins, 395, 390, 95);
            Lbl("Margin Kiri (cm)", 25, 445, 125);    left = Box(Margins, 155, 440, 95);
            Lbl("Margin Kanan (cm)", 270, 445, 125);  right = Box(Margins, 395, 440, 95);

            Controls.Add(new Label
            {
                Text = "Jarak BAB juga dipakai untuk judul Non-BAB dan judul daftar (Daftar Isi, dst.). Margin diterapkan ke seluruh section.",
                Left = 25, Top = 495, Width = 690, Height = 34, ForeColor = Color.Gray
            });

            var apply = new Button { Text = "Terapkan", Left = 560, Top = 390, Width = 130, Height = 45 };
            apply.Click += (s, e) => Apply();
            var cancel = new Button { Text = "Batal", Left = 560, Top = 445, Width = 130, Height = 35 };
            cancel.Click += (s, e) => Close();
            Controls.Add(apply); Controls.Add(cancel);
        }

        static string Fmt(float v)
        {
            return v.ToString("0.##", CultureInfo.InvariantCulture);
        }

        // Isi awal dialog diambil dari dokumen yang sedang aktif, bukan angka bawaan.
        void LoadFromDocument()
        {
            // nilai bawaan (jika dokumen belum diformat)
            font.Text = "Times New Roman";
            for (int i = 0; i < 9; i++) h[i].Text = i == 0 ? "14" : "12";
            nonbab.Text = "14";
            h1before.Text = Fmt(Prefs.H1Before); h1after.Text = Fmt(Prefs.H1After);
            top.Text = "3"; bottom.Text = "3"; left.Text = "4"; right.Text = "3";
            try
            {
                font.Text = (string)doc.Styles.Item(-1).Font.Name;
                for (int i = 0; i < 9; i++) h[i].Text = Fmt((float)doc.Styles.Item(-2 - i).Font.Size);
                try { nonbab.Text = Fmt((float)doc.Styles.Item(Engine.NonBabStyle).Font.Size); } catch { }
                dynamic h1 = doc.Styles.Item(-2).ParagraphFormat;
                h1before.Text = Fmt((float)h1.SpaceBefore); h1after.Text = Fmt((float)h1.SpaceAfter);
                dynamic ps = doc.PageSetup;
                top.Text = Fmt((float)ps.TopMargin / CmPt); bottom.Text = Fmt((float)ps.BottomMargin / CmPt);
                left.Text = Fmt((float)ps.LeftMargin / CmPt); right.Text = Fmt((float)ps.RightMargin / CmPt);
            }
            catch { }
        }

        static float F(ComboBox b)
        {
            return float.Parse(b.Text.Trim().Replace(',', '.'), CultureInfo.InvariantCulture);
        }

        void Apply()
        {
            try
            {
                var sizes = new float[9];
                for (int i = 0; i < 9; i++) sizes[i] = F(h[i]);
                float nb = F(nonbab);
                float hb = F(h1before), ha = F(h1after);
                float t = F(top), b = F(bottom), l = F(left), r = F(right);

                if (hb < 0 || hb > 200 || ha < 0 || ha > 200)
                { MessageBox.Show("Jarak BAB harus antara 0 dan 200 pt.", "SC by chandraoktya"); return; }
                foreach (float m in new float[] { t, b, l, r })
                    if (m < 0.5f || m > 10f) { MessageBox.Show("Margin harus antara 0,5 dan 10 cm.", "SC by chandraoktya"); return; }
                dynamic ps = doc.PageSetup;
                float pw = (float)ps.PageWidth / CmPt, ph = (float)ps.PageHeight / CmPt;
                if (pw - (l + r) < 5f || ph - (t + b) < 5f)
                { MessageBox.Show("Margin terlalu besar: area teks kurang dari 5 cm.", "SC by chandraoktya"); return; }

                Prefs.SetFloat("H1Before", hb);
                Prefs.SetFloat("H1After", ha);
                Engine.ApplyCustomPreset(doc, font.Text, sizes, nb, t, b, l, r);
                MessageBox.Show("Format diterapkan.", "SC by chandraoktya");
                Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Isi ukuran font, jarak, dan margin dengan angka yang valid.", "SC by chandraoktya");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal menerapkan format:\n" + ex.Message, "SC by chandraoktya");
            }
        }
    }
}
