# SC by chandraoktya (COM Add-in Word, non-VSTO)

Dibuat oleh Chandra Tri Oktyawardhana.

Add-in Word desktop (Windows) untuk formatting skripsi/laporan berbasis template UPN.
C# (mcs) tanpa Visual Studio; late-binding ke Word, tanpa Office PIA. Installer berupa aplikasi .NET (WinForms)
yang menanam DLL add-in dan QR donasi, dengan manifest asInvoker (tanpa admin) dan version info.

- Install per-user (HKCU). Butuh .NET Framework 4.8 (bawaan Windows 10/11).
- Uninstall: Settings > Apps > "SC by chandraoktya".
- Build ulang: `./build.sh` (butuh `mono-mcs` dan `binutils-mingw-w64-x86-64`).
- Log: `%LOCALAPPDATA%\SC_by_chandraoktya\log.txt`.
