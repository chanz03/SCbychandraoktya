using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("SC by chandraoktya Setup")]
[assembly: AssemblyCompany("chandraoktya.id")]
[assembly: AssemblyProduct("SC by chandraoktya")]
[assembly: AssemblyCopyright("Copyright (c) 2026 chandraoktya.id (Chandra Tri Oktyawardhana)")]
[assembly: AssemblyVersion("1.0.9.0")]

namespace SCSetup
{
    static class Cfg
    {
        public const string AppName = "SC by chandraoktya";
        public const string Author = "Chandra Tri Oktyawardhana";
        public const string Publisher = "chandraoktya.id";
        public const string Version = "1.0.9";
        public const string ProgId = "SCbychandraoktya.Connect";
        public const string Clsid = "{7C0E3B5A-2D4F-4B8E-9A61-5C3F1E8D2A47}";
        public const string Dll = "SC_by_chandraoktya.dll";
        public const string AsmName = "SC_by_chandraoktya, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null";
        public const string UninstKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\SCbychandraoktya";
        public const string Instagram = "https://www.instagram.com/chandraoktya/";
    }

    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length > 0 && args[0].Equals("/uninstall", StringComparison.OrdinalIgnoreCase))
            {
                Installer.RunUninstall();
                return;
            }
            Application.Run(new SetupForm());
        }
    }

    // ---------------------------------------------------------------- install / uninstall logic
    static class Installer
    {
        public static string BaseDir
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SC_by_chandraoktya"); }
        }

        public static bool WordRunning()
        {
            try { return Process.GetProcessesByName("WINWORD").Length > 0; }
            catch { return false; }
        }

        static void WriteRes(string name, string path)
        {
            using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
            using (var f = new FileStream(path, FileMode.Create, FileAccess.Write))
            {
                var buf = new byte[81920]; int n;
                while ((n = s.Read(buf, 0, buf.Length)) > 0) f.Write(buf, 0, n);
            }
        }

        public static void Install()
        {
            string verDir = Path.Combine(BaseDir, Cfg.Version);
            Directory.CreateDirectory(Path.Combine(verDir, "Assets"));
            string dll = Path.Combine(verDir, Cfg.Dll);
            WriteRes("payload.dll", dll);
            WriteRes("donation_qr.png", Path.Combine(verDir, "Assets", "donation_qr.png"));

            try { File.Copy(Application.ExecutablePath, Path.Combine(BaseDir, "Uninstall.exe"), true); } catch { }
            CleanOldVersions(verDir);

            string codeBase = new Uri(dll).AbsoluteUri;
            foreach (RegistryView view in new RegistryView[] { RegistryView.Registry64, RegistryView.Registry32 })
            {
                try
                {
                    using (var hkcu = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, view))
                        WriteAll(hkcu, codeBase);
                }
                catch { }
            }

            // bersihkan status "add-in dinonaktifkan" dari percobaan sebelumnya
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Office\16.0\Word\Resiliency", true))
                {
                    if (k != null)
                    {
                        k.DeleteSubKeyTree("DisabledItems", false);
                        k.DeleteSubKeyTree("CrashingAddinList", false);
                    }
                }
            }
            catch { }

            using (var k = Registry.CurrentUser.CreateSubKey(Cfg.UninstKey))
            {
                k.SetValue("DisplayName", Cfg.AppName);
                k.SetValue("DisplayVersion", Cfg.Version);
                k.SetValue("Publisher", Cfg.Publisher);
                k.SetValue("DisplayIcon", Path.Combine(BaseDir, "Uninstall.exe"));
                k.SetValue("UninstallString", "\"" + Path.Combine(BaseDir, "Uninstall.exe") + "\" /uninstall");
                k.SetValue("InstallLocation", BaseDir);
                k.SetValue("NoModify", 1, RegistryValueKind.DWord);
                k.SetValue("NoRepair", 1, RegistryValueKind.DWord);
            }
        }

        static void CleanOldVersions(string keepDir)
        {
            try
            {
                foreach (string d in Directory.GetDirectories(BaseDir))
                {
                    string name = Path.GetFileName(d);
                    if (name.Length > 0 && char.IsDigit(name[0]) && !string.Equals(d, keepDir, StringComparison.OrdinalIgnoreCase))
                        try { Directory.Delete(d, true); } catch { }
                }
                try { File.Delete(Path.Combine(BaseDir, Cfg.Dll)); } catch { }
                try { Directory.Delete(Path.Combine(BaseDir, "Assets"), true); } catch { }
            }
            catch { }
        }

        static void SetAsm(RegistryKey k, string codeBase)
        {
            k.SetValue("Class", Cfg.ProgId);
            k.SetValue("Assembly", Cfg.AsmName);
            k.SetValue("RuntimeVersion", "v4.0.30319");
            k.SetValue("CodeBase", codeBase);
        }

        static void WriteAll(RegistryKey hkcu, string codeBase)
        {
            using (var k = hkcu.CreateSubKey(@"Software\Classes\" + Cfg.ProgId))
            {
                k.SetValue("", Cfg.AppName);
                using (var c = k.CreateSubKey("CLSID")) c.SetValue("", Cfg.Clsid);
            }
            using (var k = hkcu.CreateSubKey(@"Software\Classes\CLSID\" + Cfg.Clsid))
            {
                k.SetValue("", Cfg.ProgId);
                using (var p = k.CreateSubKey("ProgId")) p.SetValue("", Cfg.ProgId);
                using (var i = k.CreateSubKey("InprocServer32"))
                {
                    i.SetValue("", "mscoree.dll");
                    i.SetValue("ThreadingModel", "Both");
                    SetAsm(i, codeBase);
                    using (var v = i.CreateSubKey("1.0.0.0")) SetAsm(v, codeBase);
                }
                using (var cat = k.CreateSubKey(@"Implemented Categories\{62C8FE65-4EBB-45E7-B440-6E39B2CDBF29}")) { }
            }
            using (var k = hkcu.CreateSubKey(@"Software\Microsoft\Office\Word\Addins\" + Cfg.ProgId))
            {
                k.SetValue("FriendlyName", Cfg.AppName);
                k.SetValue("Description", "Formatting assistant skripsi/laporan");
                k.SetValue("LoadBehavior", 3, RegistryValueKind.DWord);
            }
        }

        public static void RunUninstall()
        {
            if (WordRunning())
            {
                MessageBox.Show("Tutup Microsoft Word terlebih dahulu, lalu jalankan uninstall lagi.", Cfg.AppName);
                return;
            }
            if (MessageBox.Show("Hapus " + Cfg.AppName + " dari komputer ini?", Cfg.AppName + " - Uninstall",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            foreach (RegistryView view in new RegistryView[] { RegistryView.Registry64, RegistryView.Registry32 })
            {
                try
                {
                    using (var hkcu = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, view))
                    {
                        hkcu.DeleteSubKeyTree(@"Software\Classes\" + Cfg.ProgId, false);
                        hkcu.DeleteSubKeyTree(@"Software\Classes\CLSID\" + Cfg.Clsid, false);
                        hkcu.DeleteSubKeyTree(@"Software\Microsoft\Office\Word\Addins\" + Cfg.ProgId, false);
                    }
                }
                catch { }
            }
            try { Registry.CurrentUser.DeleteSubKeyTree(Cfg.UninstKey, false); } catch { }
            try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\SC_by_chandraoktya", false); } catch { }

            try
            {
                // folder dihapus setelah proses ini selesai (file Uninstall.exe sedang berjalan)
                var psi = new ProcessStartInfo("cmd.exe", "/c ping 127.0.0.1 -n 3 >nul & rmdir /s /q \"" + BaseDir + "\"");
                psi.CreateNoWindow = true; psi.UseShellExecute = false; psi.WindowStyle = ProcessWindowStyle.Hidden;
                Process.Start(psi);
            }
            catch { }
            MessageBox.Show(Cfg.AppName + " sudah dihapus.", Cfg.AppName);
        }
    }

    // ---------------------------------------------------------------- UI
    class SetupForm : Form
    {
        const int W = 920, H = 560, SPLIT = 460;
        enum State { Ready, Installing, Done, Error }

        static readonly Color PanelL = Color.FromArgb(27, 27, 27);
        static readonly Color PanelR = Color.FromArgb(14, 14, 16);
        static readonly Color Card = Color.FromArgb(29, 29, 33);
        static readonly Color Blue = Color.FromArgb(76, 141, 246);
        static readonly Color BlueHover = Color.FromArgb(104, 160, 250);
        static readonly Color Muted = Color.FromArgb(150, 150, 160);

        State state = State.Ready;
        string errorText = "";
        bool wordRunning;
        bool hoverBtn, hoverClose, hoverIg;
        readonly Image logo, icon;
        readonly Timer timer = new Timer();

        readonly Rectangle closeR = new Rectangle(W - 52, 14, 36, 36);
        readonly Rectangle btnR = new Rectangle(SPLIT + 48, 380, 364, 56);
        readonly Rectangle igR = new Rectangle(SPLIT + 48 + 92, 456, 180, 24);

        [DllImport("user32.dll")] static extern bool ReleaseCapture();
        [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h, int msg, int w, int l);

        public SetupForm()
        {
            Text = Cfg.AppName + " Setup";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(W, H);
            DoubleBuffered = true;
            BackColor = PanelR;
            KeyPreview = true;
            logo = LoadImage("ui_logo.jpg");
            icon = LoadImage("app_icon.png");
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            wordRunning = Installer.WordRunning();
            timer.Interval = 1000;
            timer.Tick += (s, e) =>
            {
                bool w = Installer.WordRunning();
                if (w != wordRunning) { wordRunning = w; Invalidate(); }
            };
            timer.Start();
        }

        static Image LoadImage(string name)
        {
            using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
            using (var img = Image.FromStream(s))
                return new Bitmap(img);   // salinan, agar stream boleh ditutup
        }

        static GraphicsPath Round(Rectangle r, int rad)
        {
            int d = rad * 2;
            var p = new GraphicsPath();
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        static void Fill(Graphics g, Rectangle r, int rad, Color c)
        {
            using (var p = Round(r, rad)) using (var b = new SolidBrush(c)) g.FillPath(b, p);
        }

        static void DrawTxt(Graphics g, string s, Font f, Color c, Rectangle r, StringAlignment h, StringAlignment v)
        {
            using (var b = new SolidBrush(c))
            using (var fmt = new StringFormat { Alignment = h, LineAlignment = v, Trimming = StringTrimming.EllipsisWord })
                g.DrawString(s, f, b, r, fmt);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            // ===== panel kiri =====
            using (var b = new SolidBrush(PanelL)) g.FillRectangle(b, 0, 0, SPLIT, H);
            int lh = logo.Height * SPLIT / logo.Width;
            g.DrawImage(logo, new Rectangle(0, 60, SPLIT, lh));
            using (var f = new Font("Segoe UI", 26, FontStyle.Bold))
                DrawTxt(g, "Format Skripsi\ndalam Sekali Klik.", f, Color.White, new Rectangle(40, 355, SPLIT - 70, 100), StringAlignment.Near, StringAlignment.Near);
            using (var f = new Font("Segoe UI", 11))
                DrawTxt(g, "Rapikan heading, caption, daftar isi, dan nomor halaman di Microsoft Word secara otomatis.",
                     f, Muted, new Rectangle(40, 462, SPLIT - 90, 60), StringAlignment.Near, StringAlignment.Near);

            // ===== panel kanan =====
            int x0 = SPLIT + 48, cw = 364;
            using (var b = new SolidBrush(PanelR)) g.FillRectangle(b, SPLIT, 0, W - SPLIT, H);

            // tombol tutup
            if (hoverClose) Fill(g, closeR, 8, Color.FromArgb(50, 50, 56));
            using (var pen = new Pen(hoverClose ? Color.White : Muted, 1.6f))
            {
                g.DrawLine(pen, closeR.X + 12, closeR.Y + 12, closeR.Right - 12, closeR.Bottom - 12);
                g.DrawLine(pen, closeR.Right - 12, closeR.Y + 12, closeR.X + 12, closeR.Bottom - 12);
            }

            // ikon + judul
            var ir = new Rectangle(x0, 92, 72, 72);
            using (var p = Round(ir, 18)) { g.SetClip(p); g.DrawImage(icon, ir); g.ResetClip(); }
            using (var f = new Font("Segoe UI", 21, FontStyle.Bold))
                DrawTxt(g, Cfg.AppName, f, Color.White, new Rectangle(x0 + 88, 92, 280, 38), StringAlignment.Near, StringAlignment.Center);
            Fill(g, new Rectangle(x0 + 88, 134, 58, 22), 11, Color.FromArgb(52, 86, 150));
            using (var f = new Font("Segoe UI", 8.5f, FontStyle.Bold))
                DrawTxt(g, "Gratis", f, Color.FromArgb(190, 215, 255), new Rectangle(x0 + 88, 134, 58, 22), StringAlignment.Center, StringAlignment.Center);
            using (var f = new Font("Segoe UI", 10))
                DrawTxt(g, "Versi " + Cfg.Version + " - Official Release", f, Muted, new Rectangle(x0 + 88, 160, 280, 22), StringAlignment.Near, StringAlignment.Center);

            // kartu versi
            var vr = new Rectangle(x0, 206, cw, 52);
            Fill(g, vr, 12, Card);
            using (var f = new Font("Segoe UI", 10))
                DrawTxt(g, "Versi Add-in Tersedia", f, Muted, new Rectangle(vr.X + 16, vr.Y, 200, vr.Height), StringAlignment.Near, StringAlignment.Center);
            using (var f = new Font("Segoe UI", 10.5f, FontStyle.Bold))
                DrawTxt(g, "v" + Cfg.Version, f, Blue, new Rectangle(vr.Right - 116, vr.Y, 100, vr.Height), StringAlignment.Far, StringAlignment.Center);

            // kartu status
            var sr = new Rectangle(x0, 276, cw, 80);
            Color sBg, sFg; string sText;
            bool blocked = wordRunning && (state == State.Ready || state == State.Error);
            if (blocked) { sBg = Color.FromArgb(110, 28, 28); sFg = Color.FromArgb(255, 225, 225); sText = "Tutup Microsoft Word terlebih dahulu (termasuk yang berjalan di latar belakang), lalu klik Install."; }
            else if (state == State.Done) { sBg = Color.FromArgb(22, 70, 44); sFg = Color.FromArgb(205, 245, 220); sText = "Berhasil dipasang. Buka Microsoft Word lalu cari tab \"" + Cfg.AppName + "\" di ribbon."; }
            else if (state == State.Error) { sBg = Color.FromArgb(110, 28, 28); sFg = Color.FromArgb(255, 225, 225); sText = "Gagal memasang: " + errorText; }
            else if (state == State.Installing) { sBg = Card; sFg = Color.White; sText = "Memasang add-in..."; }
            else { sBg = Card; sFg = Color.FromArgb(215, 215, 225); sText = "Siap dipasang. Tidak memerlukan akses Administrator; hanya terpasang untuk akun Windows Anda."; }
            Fill(g, sr, 12, sBg);
            using (var f = new Font("Segoe UI", 10))
                DrawTxt(g, sText, f, sFg, new Rectangle(sr.X + 16, sr.Y + 6, sr.Width - 32, sr.Height - 12), StringAlignment.Near, StringAlignment.Center);

            // tombol utama
            bool enabled = !blocked && state != State.Installing;
            string label = state == State.Done ? "Selesai" : state == State.Installing ? "Memasang..." : state == State.Error ? "Coba Lagi" : "Install";
            Color bc = !enabled ? Color.FromArgb(52, 52, 60) : (hoverBtn ? BlueHover : Blue);
            Fill(g, btnR, 28, bc);
            using (var f = new Font("Segoe UI", 13, FontStyle.Bold))
                DrawTxt(g, label, f, enabled ? Color.White : Color.FromArgb(140, 140, 150), btnR, StringAlignment.Center, StringAlignment.Center);

            // tautan & kredit
            using (var f = new Font("Segoe UI", 9.5f, hoverIg ? FontStyle.Underline : FontStyle.Regular))
                DrawTxt(g, "Instagram @chandraoktya", f, hoverIg ? Color.White : Muted, igR, StringAlignment.Center, StringAlignment.Center);
            using (var f = new Font("Segoe UI", 9))
                DrawTxt(g, "Dibuat oleh " + Cfg.Author + "  |  " + Cfg.Publisher, f, Color.FromArgb(110, 110, 120), new Rectangle(x0, 492, cw, 20), StringAlignment.Center, StringAlignment.Center);

            using (var pen = new Pen(Color.FromArgb(48, 48, 54))) g.DrawRectangle(pen, 0, 0, W - 1, H - 1);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            bool c = closeR.Contains(e.Location);
            bool b = btnR.Contains(e.Location) && !(wordRunning && state != State.Done) && state != State.Installing;
            bool i = igR.Contains(e.Location);
            if (c != hoverClose || b != hoverBtn || i != hoverIg) { hoverClose = c; hoverBtn = b; hoverIg = i; Invalidate(); }
            Cursor = (c || b || i) ? Cursors.Hand : Cursors.Default;
            base.OnMouseMove(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (closeR.Contains(e.Location)) { Close(); return; }
                if (igR.Contains(e.Location))
                {
                    try { Process.Start(new ProcessStartInfo(Cfg.Instagram) { UseShellExecute = true }); } catch { }
                    return;
                }
                if (btnR.Contains(e.Location)) { OnMainButton(); return; }
                if (e.Y < 70 || e.X < SPLIT) { ReleaseCapture(); SendMessage(Handle, 0xA1, 2, 0); }   // geser jendela
            }
            base.OnMouseDown(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
            base.OnKeyDown(e);
        }

        void OnMainButton()
        {
            if (state == State.Installing) return;
            if (state == State.Done) { Close(); return; }
            wordRunning = Installer.WordRunning();
            if (wordRunning) { Invalidate(); return; }

            state = State.Installing; Invalidate(); Update();
            Application.DoEvents();
            try { Installer.Install(); state = State.Done; }
            catch (Exception ex) { state = State.Error; errorText = ex.Message; }
            Invalidate();
        }
    }
}
