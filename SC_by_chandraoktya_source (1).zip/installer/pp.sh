#!/bin/sh
# pengganti preprocessor untuk windres (tidak ada #include di app.rc)
for last; do :; done
cat "$last"
